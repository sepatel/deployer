function onTeamSelection(teamId) {
  if (!teamId) {
    return;
  }
  var link = $("a.brand.team-logo").attr('href', 'http://goallineblitz.com/game/team.pl?team_id=' + teamId);
  link.find("img").attr("src", "http://goallineblitz.com/game/team_pic.pl?team_id=" + teamId);

  var mainNav = $("div#links");
  mainNav.data("teamId", teamId);
  mainNav.slideDown();
  $("#link_content").slideUp();
}

function ajaxError(xhr, error, status) {
  try {
    var response = JSON.parse(xhr.responseText);
    notification(response.message, {
      title: response.error,
      type: 'error'
    });
  } catch (e) {
    notification(xhr.responseText);
  }
}

function notification(msg, options) {
  options = $.extend({
    type: 'info'
  }, options);
  var closeLink = $("<a class='close' data-dismiss='alert' href='#'>&times;</a>");
  if (options.title) {
    closeLink.html(options.title + " &times;");
  }

  var message = $("<div>").addClass("alert").html(msg).prepend(closeLink);
  if (options.type) {
    message.addClass("alert-" + options.type);
  }

  $("#alertsDialog").append(message);
  return message;
}

function getAllTeams() {
  var $data = []
  $.ajax("ws/info/teams", {
    async: false,
    dataType: 'json',
    success: function(data) {
      $.each(data, function(index, team) {
        $data.push(team.id + " - " + team.name);
      });
    }
  });
  return $data;
}

function renderGameSelectionButton(game) {
  var verses = (game.awayTeamId == teamId) ? "vs. " + game.homeTeam : game.awayTeam;
  var checkbox = $("<i>").addClass("icon-ok pull-left").hide();
  var display = $("<div>").append(verses).prepend(checkbox);
  var label = $("<button>").append(display).css("margin", "0em 0em 0.5em 0.5em").click(function() {
    checkbox.toggle();
    if (checkbox.is(":visible")) {
      $(this).data("gameId", game.gameId);
    } else {
      $(this).removeData("gameId");
    }
  });
  var win = (game.awayTeamId == teamId) ? (game.awayScore > game.homeScore) : (game.awayScore < game.homeScore);
  var score = ((win) ? "W " : "L ") + game.awayScore + " - " + game.homeScore;
  var scoreDiv = $("<div>").text(score).css("display", "inline-block");
  var scoreDiff = (game.awayTeamId == teamId) ? (game.awayScore - game.homeScore) : (game.homeScore - game.awayScore);
  label.append(scoreDiv).addClass('btn teamSelection');
  if (scoreDiff < -42) {
    label.addClass("btn-danger");
  } else if (scoreDiff < -21) {
    label.addClass("btn-warning");
  } else if (scoreDiff < 21) {
    label.addClass("btn-success");
  } else {
    label.addClass("btn-info");
  }

  if (game.week) {
    label.append("<span style='margin-left: 1em;'>Week " + game.week + "</span>");
  }
  $("#teamSelection").append(label);
}

function renderTeamsForSelection(teamId, generateReportFunction) {
  var status = notification("Loading games ...");
  $.ajax("ws/info/games/" + teamId, {
    dataType: 'json',
    type: 'GET',
    error: ajaxError,
    success: function(games) {
      status.remove();
      $.each(games, function(index, game) {
        renderGameSelectionButton(game);
      });
      var submitButton = $("<button>").text("Generate Report").addClass("btn btn-primary").click(function() {
        var gameIds = [];
        $("#teamSelection button").each(function(i, button) {
          if ($(button).data('gameId')) {
            gameIds.push($(button).data('gameId'));
          }
        });
        if (gameIds.length == 0) {
          notification("Must select a game to proceed!", {
            type: 'error'
          });
          return;
        }
        generateReportFunction(gameIds);
      });
      submitButton.css("margin-top", "15px"); // TODO: Violation of good bootstrap practice
      var navigationLink = $("<li>").append(submitButton);
      $(".nav[role=navigation]").append(navigationLink);
      $("#bread_home").one("click", function() {
        navigationLink.remove();
      });
    }
  });
}

function calculatePlayTotals(play, playbook, subTotal, grandTotal) {
  if (play.yards >= 20) {
    subTotal[5] += 1;
    grandTotal[5] += 1;
  } else if (play.yards >= 8) {
    subTotal[4] += 1;
    grandTotal[4] += 1;
  } else if (play.yards >= 5) {
    subTotal[3] += 1;
    grandTotal[3] += 1;
  } else if (play.yards < 0) {
    subTotal[0] += 1;
    grandTotal[0] += 1;
  } else if (playbook.type.indexOf("Run") == 0 || playbook.type == "Pass_Screen") {
    if (play.yards >= 2.5) {
      subTotal[2] += 1;
      grandTotal[2] += 1;
    } else if (play.yards >= 1.5) {
      subTotal[1] += 1;
      grandTotal[1] += 1;
    } else {
      subTotal[0] += 1;
      grandTotal[0] += 1;
    }
  } else if (playbook.type == "Pass_Deep" || playbook.type == "Pass_Medium" || playbook.type == "Pass_Short") {
    if (play.complete) {
      subTotal[2] += 1;
      grandTotal[2] += 1;
    } else if (play.bad) {
      subTotal[1] += 1;
      grandTotal[1] += 1;
    } else {
      subTotal[0] += 1;
      grandTotal[0] += 1;
    }
  }
}


